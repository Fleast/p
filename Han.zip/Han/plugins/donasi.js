let handler = async m => m.reply(`
╭─「 Donasi Via Pulsa 」
│ • Tri [089636124939]
│ • Telkomsel [081211291620]
╰────「 Hanbei BOT 」

Apa Keuntungan DONASI ?
• Menjaga Agar Bot Tetap Update & Aktif
• Kamu Bisa Mengundang Bot Ke Group
• Kamu Bisa Akses Jadi BOT
• Kamu Akan Menjadi PREMIUM
• Kamu Bisa Request Fitur
• Membantu Owner :)

`.trim()) // Tambah sendiri kalo mau
handler.help = ['donasi']
handler.tags = ['info']
handler.command = /^dona(te|si)$/i

module.exports = handler
